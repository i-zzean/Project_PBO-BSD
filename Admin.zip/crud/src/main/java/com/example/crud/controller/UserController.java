package com.example.crud.controller;

import com.example.crud.entity.User;
import com.example.crud.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserRepository repository;

    // Password disimpan dalam bentuk hash (BCrypt), bukan teks asli
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public UserController(UserRepository repository) {
        this.repository = repository;
    }

    // READ - menampilkan seluruh data
    @GetMapping
    public String index(Model model) {

        model.addAttribute("daftarUser", repository.findAll());

        return "user/index";
    }

    // CREATE
    @PostMapping("/simpan")
    public String simpan(
            @ModelAttribute User user,
            RedirectAttributes redirect) {

        try {

            if (user.getNama() == null || user.getNama().isBlank()) {
                throw new IllegalArgumentException("Nama wajib diisi!");
            }

            if (user.getEmail() == null || user.getEmail().isBlank()) {
                throw new IllegalArgumentException("Email wajib diisi!");
            }

            if (user.getPassword() == null || user.getPassword().isBlank()) {
                throw new IllegalArgumentException("Password wajib diisi!");
            }

            if (repository.existsByEmail(user.getEmail())) {
                throw new IllegalArgumentException("Email sudah terdaftar!");
            }

            user.setIdUser(null);
            user.setPassword(encoder.encode(user.getPassword()));

            repository.save(user);

            redirect.addFlashAttribute(
                    "sukses", "Data user berhasil ditambahkan!");

        } catch (Exception e) {

            redirect.addFlashAttribute(
                    "gagal", "Gagal menambahkan data: " + e.getMessage());
        }

        return "redirect:/user";
    }

    // UPDATE
    @PostMapping("/update/{id}")
    public String update(
            @PathVariable Long id,
            @ModelAttribute User form,
            RedirectAttributes redirect) {

        try {

            User user = repository.findById(id)
                    .orElseThrow(() ->
                            new IllegalArgumentException("Data user tidak ditemukan!"));

            if (form.getNama() == null || form.getNama().isBlank()) {
                throw new IllegalArgumentException("Nama wajib diisi!");
            }

            if (form.getEmail() == null || form.getEmail().isBlank()) {
                throw new IllegalArgumentException("Email wajib diisi!");
            }

            if (repository.existsByEmailAndIdUserNot(form.getEmail(), id)) {
                throw new IllegalArgumentException("Email sudah dipakai user lain!");
            }

            user.setNama(form.getNama());
            user.setEmail(form.getEmail());
            user.setNoTelp(form.getNoTelp());
            user.setPeran(form.getPeran());

            // Password hanya diganti jika kolomnya diisi
            if (form.getPassword() != null && !form.getPassword().isBlank()) {
                user.setPassword(encoder.encode(form.getPassword()));
            }

            repository.save(user);

            redirect.addFlashAttribute(
                    "sukses", "Data user berhasil diperbarui!");

        } catch (Exception e) {

            redirect.addFlashAttribute(
                    "gagal", "Gagal memperbarui data: " + e.getMessage());
        }

        return "redirect:/user";
    }

    // DELETE
    @PostMapping("/hapus/{id}")
    public String hapus(
            @PathVariable Long id,
            RedirectAttributes redirect) {

        try {

            if (!repository.existsById(id)) {
                throw new IllegalArgumentException("Data tidak ditemukan!");
            }

            repository.deleteById(id);

            redirect.addFlashAttribute(
                    "sukses", "Data user berhasil dihapus!");

        } catch (Exception e) {

            redirect.addFlashAttribute(
                    "gagal", "Gagal menghapus data: " + e.getMessage());
        }

        return "redirect:/user";
    }
}
