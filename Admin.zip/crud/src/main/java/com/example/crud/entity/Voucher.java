package com.example.crud.entity;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;

@Entity
@Table(name = "voucher")
public class Voucher {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_voucher")
    private Long idVoucher;

    @Column(name = "jenis_voucher")
    private String jenisVoucher;

    @Column(name = "nilai_potongan")
    private Long nilaiPotongan;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name = "masa_berlaku")
    private LocalDate masaBerlaku;

    @Column(name = "batas_penggunaan")
    private Integer batasPenggunaan;

    @Column(name = "syarat_ketentuan", columnDefinition = "TEXT")
    private String syaratKetentuan;

    @Column(name = "poin_dibutuhkan")
    private Integer poinDibutuhkan;

    public Voucher() {
    }

    public Long getIdVoucher() { return idVoucher; }
    public void setIdVoucher(Long idVoucher) { this.idVoucher = idVoucher; }

    public String getJenisVoucher() { return jenisVoucher; }
    public void setJenisVoucher(String jenisVoucher) { this.jenisVoucher = jenisVoucher; }

    public Long getNilaiPotongan() { return nilaiPotongan; }
    public void setNilaiPotongan(Long nilaiPotongan) { this.nilaiPotongan = nilaiPotongan; }

    public LocalDate getMasaBerlaku() { return masaBerlaku; }
    public void setMasaBerlaku(LocalDate masaBerlaku) { this.masaBerlaku = masaBerlaku; }

    public Integer getBatasPenggunaan() { return batasPenggunaan; }
    public void setBatasPenggunaan(Integer batasPenggunaan) { this.batasPenggunaan = batasPenggunaan; }

    public String getSyaratKetentuan() { return syaratKetentuan; }
    public void setSyaratKetentuan(String syaratKetentuan) { this.syaratKetentuan = syaratKetentuan; }

    public Integer getPoinDibutuhkan() { return poinDibutuhkan; }
    public void setPoinDibutuhkan(Integer poinDibutuhkan) { this.poinDibutuhkan = poinDibutuhkan; }
}
