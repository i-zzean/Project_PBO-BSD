package com.example.crud.repository;

import com.example.crud.entity.Donasi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonasiRepository extends JpaRepository<Donasi, Long> {

}
