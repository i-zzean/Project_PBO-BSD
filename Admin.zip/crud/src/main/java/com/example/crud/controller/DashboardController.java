package com.example.crud.controller;

import com.example.crud.repository.DonasiRepository;
import com.example.crud.repository.UserRepository;
import com.example.crud.repository.VoucherRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final UserRepository userRepository;
    private final DonasiRepository donasiRepository;
    private final VoucherRepository voucherRepository;

    public DashboardController(
            UserRepository userRepository,
            DonasiRepository donasiRepository,
            VoucherRepository voucherRepository) {

        this.userRepository = userRepository;
        this.donasiRepository = donasiRepository;
        this.voucherRepository = voucherRepository;
    }

    // Halaman dashboard (welcome)
    @GetMapping("/")
    public String dashboard(Model model) {

        model.addAttribute("jumlahUser", userRepository.count());
        model.addAttribute("jumlahDonasi", donasiRepository.count());
        model.addAttribute("jumlahVoucher", voucherRepository.count());

        return "dashboard";
    }
}
