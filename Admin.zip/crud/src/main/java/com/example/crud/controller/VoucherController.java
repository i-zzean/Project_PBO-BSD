package com.example.crud.controller;

import com.example.crud.entity.Voucher;
import com.example.crud.repository.VoucherRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/voucher")
public class VoucherController {

    private final VoucherRepository repository;

    public VoucherController(VoucherRepository repository) {
        this.repository = repository;
    }

    // READ - menampilkan seluruh data
    @GetMapping
    public String index(Model model) {

        model.addAttribute("daftarVoucher", repository.findAll());

        return "voucher/index";
    }

    // CREATE
    @PostMapping("/simpan")
    public String simpan(
            @ModelAttribute Voucher voucher,
            RedirectAttributes redirect) {

        try {

            validasi(voucher);

            voucher.setIdVoucher(null);
            repository.save(voucher);

            redirect.addFlashAttribute(
                    "sukses", "Data voucher berhasil ditambahkan!");

        } catch (Exception e) {

            redirect.addFlashAttribute(
                    "gagal", "Gagal menambahkan data: " + e.getMessage());
        }

        return "redirect:/voucher";
    }

    // UPDATE
    @PostMapping("/update/{id}")
    public String update(
            @PathVariable Long id,
            @ModelAttribute Voucher form,
            RedirectAttributes redirect) {

        try {

            Voucher voucher = repository.findById(id)
                    .orElseThrow(() ->
                            new IllegalArgumentException("Data voucher tidak ditemukan!"));

            validasi(form);

            voucher.setJenisVoucher(form.getJenisVoucher());
            voucher.setNilaiPotongan(form.getNilaiPotongan());
            voucher.setMasaBerlaku(form.getMasaBerlaku());
            voucher.setBatasPenggunaan(form.getBatasPenggunaan());
            voucher.setSyaratKetentuan(form.getSyaratKetentuan());
            voucher.setPoinDibutuhkan(form.getPoinDibutuhkan());

            repository.save(voucher);

            redirect.addFlashAttribute(
                    "sukses", "Data voucher berhasil diperbarui!");

        } catch (Exception e) {

            redirect.addFlashAttribute(
                    "gagal", "Gagal memperbarui data: " + e.getMessage());
        }

        return "redirect:/voucher";
    }

    // DELETE
    @PostMapping("/hapus/{id}")
    public String hapus(
            @PathVariable Long id,
            RedirectAttributes redirect) {

        try {

            if (!repository.existsById(id)) {
                throw new IllegalArgumentException("Data tidak ditemukan!");
            }

            repository.deleteById(id);

            redirect.addFlashAttribute(
                    "sukses", "Data voucher berhasil dihapus!");

        } catch (Exception e) {

            redirect.addFlashAttribute(
                    "gagal", "Gagal menghapus data: " + e.getMessage());
        }

        return "redirect:/voucher";
    }

    private void validasi(Voucher v) {

        if (v.getJenisVoucher() == null || v.getJenisVoucher().isBlank()) {
            throw new IllegalArgumentException("Jenis voucher wajib diisi!");
        }

        if (v.getNilaiPotongan() == null || v.getNilaiPotongan() < 0) {
            throw new IllegalArgumentException("Nilai potongan tidak valid!");
        }

        if (v.getMasaBerlaku() == null) {
            throw new IllegalArgumentException("Masa berlaku wajib diisi!");
        }

        if (v.getBatasPenggunaan() == null || v.getBatasPenggunaan() < 0) {
            throw new IllegalArgumentException("Batas penggunaan tidak valid!");
        }

        if (v.getPoinDibutuhkan() == null || v.getPoinDibutuhkan() < 0) {
            throw new IllegalArgumentException("Poin dibutuhkan tidak valid!");
        }
    }
}
