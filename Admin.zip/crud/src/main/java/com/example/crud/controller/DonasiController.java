package com.example.crud.controller;

import com.example.crud.entity.Donasi;
import com.example.crud.repository.DonasiRepository;
import com.example.crud.service.FileStorageService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/donasi")
public class DonasiController {
    private final DonasiRepository repository;
    private final FileStorageService fileService;

    public DonasiController(DonasiRepository repository, FileStorageService fileService) {
        this.repository = repository;
        this.fileService = fileService;
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("daftarDonasi", repository.findAll());
        return "donasi/index";
    }

    @PostMapping("/simpan")
    public String simpan(@ModelAttribute Donasi donasi,
                         @RequestParam(value = "fileFoto", required = false) MultipartFile foto,
                         RedirectAttributes redirect) {
        try {
            validasi(donasi);
            if (foto == null || foto.isEmpty()) throw new IllegalArgumentException("Foto bukti donasi wajib diunggah!");
            donasi.setIdDonasi(null);
            donasi.setFoto(fileService.simpanFoto(foto, donasi.getNamaDonatur()));
            repository.save(donasi);
            redirect.addFlashAttribute("sukses", "Data donasi berhasil ditambahkan!");
        } catch (Exception e) {
            redirect.addFlashAttribute("gagal", "Gagal menambahkan data: " + e.getMessage());
        }
        return "redirect:/donasi";
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, @ModelAttribute Donasi form,
                         @RequestParam(value = "fileFoto", required = false) MultipartFile foto,
                         RedirectAttributes redirect) {
        try {
            Donasi donasi = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Data donasi tidak ditemukan!"));
            validasi(form);
            String fotoLama = donasi.getFoto();
            donasi.setTanggal(form.getTanggal());
            donasi.setStatus(form.getStatus());
            donasi.setNamaDonatur(form.getNamaDonatur());
            donasi.setEmail(form.getEmail());
            donasi.setNoTelp(form.getNoTelp());
            donasi.setJenisPakaian(form.getJenisPakaian());
            donasi.setJumlah(form.getJumlah());
            donasi.setKondisi(form.getKondisi());
            donasi.setAlamat(form.getAlamat());
            donasi.setCatatan(form.getCatatan());
            boolean gantiFoto = foto != null && !foto.isEmpty();
            if (gantiFoto) donasi.setFoto(fileService.simpanFoto(foto, form.getNamaDonatur()));
            repository.save(donasi);
            if (gantiFoto && fotoLama != null) {
                try { fileService.hapusFoto(fotoLama); } catch (Exception ignored) {}
            }
            redirect.addFlashAttribute("sukses", "Data donasi berhasil diperbarui!");
        } catch (Exception e) {
            redirect.addFlashAttribute("gagal", "Gagal memperbarui data: " + e.getMessage());
        }
        return "redirect:/donasi";
    }

    @PostMapping("/hapus/{id}")
    public String hapus(@PathVariable Long id, RedirectAttributes redirect) {
        try {
            Donasi donasi = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Data tidak ditemukan!"));
            repository.delete(donasi);
            if (donasi.getFoto() != null) {
                try { fileService.hapusFoto(donasi.getFoto()); } catch (Exception ignored) {}
            }
            redirect.addFlashAttribute("sukses", "Data donasi berhasil dihapus!");
        } catch (Exception e) {
            redirect.addFlashAttribute("gagal", "Gagal menghapus data: " + e.getMessage());
        }
        return "redirect:/donasi";
    }

    private void validasi(Donasi d) {
        if (d.getTanggal() == null) throw new IllegalArgumentException("Tanggal wajib diisi!");
        if (d.getNamaDonatur() == null || d.getNamaDonatur().isBlank()) throw new IllegalArgumentException("Nama donatur wajib diisi!");
        if (d.getJenisPakaian() == null || d.getJenisPakaian().isBlank()) throw new IllegalArgumentException("Jenis pakaian wajib dipilih!");
        if (d.getJumlah() == null || d.getJumlah() < 1) throw new IllegalArgumentException("Jumlah pakaian minimal 1!");
        if (d.getKondisi() == null || d.getKondisi().isBlank()) throw new IllegalArgumentException("Kondisi pakaian wajib dipilih!");
        if (d.getStatus() == null || d.getStatus().isBlank()) throw new IllegalArgumentException("Status wajib dipilih!");
    }
}
