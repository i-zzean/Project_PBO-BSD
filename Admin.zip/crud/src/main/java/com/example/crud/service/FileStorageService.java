package com.example.crud.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.*;
import java.text.Normalizer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Service
public class FileStorageService {
    private final Path folder = Paths.get("images").toAbsolutePath().normalize();

    public String simpanFoto(MultipartFile file, String nama) throws IOException {
        if (file == null || file.isEmpty()) return null;
        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/"))
            throw new IOException("File harus berupa gambar!");
        String original = file.getOriginalFilename();
        String ext = "";
        if (original != null && original.contains("."))
            ext = original.substring(original.lastIndexOf(".")).toLowerCase(Locale.ROOT);
        if (!ext.matches("\\.(jpg|jpeg|png|webp|gif)"))
            throw new IOException("Format foto harus JPG, JPEG, PNG, WEBP, atau GIF!");
        Files.createDirectories(folder);
        String safe = Normalizer.normalize(nama == null ? "donasi" : nama, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").replaceAll("[^a-zA-Z0-9_-]", "_");
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
        String filename = stamp + "_" + safe + ext;
        Path target = folder.resolve(filename).normalize();
        if (!target.startsWith(folder)) throw new IOException("Nama file tidak valid!");
        Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
        return "/images/" + filename;
    }

    public void hapusFoto(String pathFoto) throws IOException {
        if (pathFoto == null || pathFoto.isBlank()) return;
        String filename = Paths.get(pathFoto).getFileName().toString();
        Path target = folder.resolve(filename).normalize();
        if (target.startsWith(folder)) Files.deleteIfExists(target);
    }
}
