package com.example.crud.entity;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;

@Entity
@Table(name = "donasi")
public class Donasi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_donasi")
    private Long idDonasi;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate tanggal;
    private String status;
    @Column(name = "nama_donatur")
    private String namaDonatur;
    private String email;
    @Column(name = "no_telp")
    private String noTelp;
    @Column(name = "jenis_pakaian")
    private String jenisPakaian;
    private Integer jumlah;
    private String kondisi;
    @Column(columnDefinition = "TEXT")
    private String alamat;
    @Column(columnDefinition = "TEXT")
    private String catatan;
    private String foto;

    public Donasi() {}
    public Long getIdDonasi() { return idDonasi; }
    public void setIdDonasi(Long idDonasi) { this.idDonasi = idDonasi; }
    public LocalDate getTanggal() { return tanggal; }
    public void setTanggal(LocalDate tanggal) { this.tanggal = tanggal; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getNamaDonatur() { return namaDonatur; }
    public void setNamaDonatur(String namaDonatur) { this.namaDonatur = namaDonatur; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getNoTelp() { return noTelp; }
    public void setNoTelp(String noTelp) { this.noTelp = noTelp; }
    public String getJenisPakaian() { return jenisPakaian; }
    public void setJenisPakaian(String jenisPakaian) { this.jenisPakaian = jenisPakaian; }
    public Integer getJumlah() { return jumlah; }
    public void setJumlah(Integer jumlah) { this.jumlah = jumlah; }
    public String getKondisi() { return kondisi; }
    public void setKondisi(String kondisi) { this.kondisi = kondisi; }
    public String getAlamat() { return alamat; }
    public void setAlamat(String alamat) { this.alamat = alamat; }
    public String getCatatan() { return catatan; }
    public void setCatatan(String catatan) { this.catatan = catatan; }
    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }
}
