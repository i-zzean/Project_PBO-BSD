// Utilitas antarmuka LemariKita
function aktifkanTabel(selector) {
  const el = document.querySelector(selector);
  if (!el || typeof DataTable === "undefined") return;
  new DataTable(selector, {
    pageLength: 5,
    lengthMenu: [5, 10, 25, 50],
    order: [[0, "asc"]],
    scrollX: true,
    language: {
      search: "Cari:",
      lengthMenu: "Tampilkan _MENU_ data",
      info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
      infoEmpty: "Tidak ada data",
      zeroRecords: "Data tidak ditemukan",
      emptyTable: "Belum ada data untuk ditampilkan",
      paginate: { first: "Awal", last: "Akhir", next: "Berikutnya", previous: "Sebelumnya" }
    }
  });
}
