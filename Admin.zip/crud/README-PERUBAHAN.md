# Pembaruan LemariKita CRUD

## Pembaruan tampilan
- Tema admin diperbarui mengikuti referensi LemariKita: navbar putih, aksen biru, latar abu muda, font Poppins, card rounded, dan hero gradient.
- Dashboard dirapikan dengan ringkasan jumlah pengguna, donasi, dan voucher.
- Navigasi aktif untuk Beranda, Pengguna, Donasi, dan Voucher.

## CRUD Donasi
Data donasi kini mencakup:
- Nama donatur, email, nomor telepon, tanggal, alamat.
- Jenis pakaian, jumlah (pcs), kondisi, status, dan catatan.
- Foto bukti donasi.

## Upload foto
Mengikuti pola project `sepakbola.zip`:
- File gambar disimpan di folder `images/` pada direktori kerja aplikasi.
- Database menyimpan path foto, bukan binary.
- Saat edit, foto lama dipertahankan jika tidak ada foto baru; foto lama dihapus setelah foto baru berhasil disimpan.
- Saat hapus data, file foto terkait ikut dihapus.
- Format yang diterima: JPG, JPEG, PNG, WEBP, GIF.
- Batas upload: 8 MB per file.

## Database
Entity Donasi mendapat kolom tambahan. Dengan `spring.jpa.hibernate.ddl-auto=update`, Hibernate akan menambahkan kolom baru saat aplikasi dijalankan. Tetap lakukan backup database sebelum deploy.

## Menjalankan
Jalankan aplikasi Spring Boot seperti biasa. Folder `images/` dibuat otomatis saat foto pertama kali diunggah.
